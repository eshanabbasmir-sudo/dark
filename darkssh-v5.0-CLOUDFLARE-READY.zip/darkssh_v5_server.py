#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║   🚀 DARKSSH v5.0 - UNIVERSAL CLOUDFLARE-READY SERVER 🔥                     ║
║   ─────────────────────────────────────────                                   ║
║                                                                               ║
║   ✅ 100% Universal - Works EVERYWHERE!                                       ║
║   ✅ Cloudflare Tunnel Compatible                                             ║
║   ✅ No More 502 Errors!                                                      ║
║   ✅ Never Crashes - All Errors Handled!                                      ║
║   ✅ Valid JSON Responses Always!                                             ║
║   ✅ Terminal Ready - No GitHub Needed!                                       ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝

Author: Prime Automation
Version: 5.0.0 (Cloudflare-Ready Stable Release)
License: MIT
"""

import json
import os
import re
import sys
import time
import signal
import socket
import threading
import secrets
import shutil
import subprocess
import tempfile
import traceback
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from datetime import datetime
from socketserver import ThreadingMixIn
from concurrent.futures import ThreadPoolExecutor, Future
from typing import Dict, Any, Optional, Tuple
import argparse

# ============================================================================
# CONFIGURATION
# ============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
DATA_DIR = SCRIPT_DIR / "data"
SESSIONS_DIR = DATA_DIR / "sessions"
LOGS_DIR = SCRIPT_DIR / "logs"
CONFIG_FILE = SCRIPT_DIR / "config.json"
STATE_FILE = DATA_DIR / "state.json"

# Create directories
for d in [DATA_DIR, SESSIONS_DIR, LOGS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ============================================================================
# LOGGING SYSTEM (Crash-Proof)
# ============================================================================

class Logger:
    """Crash-proof logging system"""
    
    def __init__(self, debug=False):
        self.debug_mode = debug
        self.log_file = None
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_path = LOGS_DIR / f"darkssh_{timestamp}.log"
            self.log_file = open(log_path, 'a', encoding='utf-8')
        except Exception:
            pass
    
    def _log(self, level, message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{timestamp}] [{level}] {message}"
        
        # Console output
        if level == "ERROR":
            print(f"❌ {message}", flush=True)
        elif level == "WARNING":
            print(f"⚠️  {message}", flush=True)
        elif level == "SUCCESS":
            print(f"✅ {message}", flush=True)
        elif level == "DEBUG" and self.debug_mode:
            print(f"🔍 {message}", flush=True)
        else:
            print(f"ℹ️  {message}", flush=True)
        
        # File output
        if self.log_file:
            try:
                self.log_file.write(line + "\n")
                self.log_file.flush()
            except Exception:
                pass
    
    def info(self, msg): self._log("INFO", msg)
    def error(self, msg): self._log("ERROR", msg)
    def warning(self, msg): self._log("WARNING", msg)
    def success(self, msg): self._log("SUCCESS", msg)
    def debug(self, msg): self._log("DEBUG", msg)
    
    def close(self):
        if self.log_file:
            try:
                self.log_file.close()
            except Exception:
                pass

# Global logger
logger = Logger()

# ============================================================================
# CONFIGURATION MANAGER
# ============================================================================

DEFAULT_CONFIG = {
    "host": "0.0.0.0",
    "port": 4545,
    "api_key": "",
    "max_sessions": 25,
    "idle_minutes": 30,
    "session_timeout": 120,
    "debug": False,
    "universal_mode": True,
    "cloudflare_ready": True,
    "enable_outbound": True,
    "base_port": 10000,
    "ports_per_session": 10,
}

def load_config() -> Dict[str, Any]:
    """Load configuration with crash protection"""
    config = DEFAULT_CONFIG.copy()
    
    try:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, 'r') as f:
                file_config = json.load(f)
                config.update(file_config)
            logger.success(f"Configuration loaded from {CONFIG_FILE}")
        else:
            # Create default config
            save_config(config)
            logger.info("Created default configuration")
    except Exception as e:
        logger.warning(f"Config load error (using defaults): {e}")
    
    return config

def save_config(config: Dict[str, Any]):
    """Save configuration safely"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        logger.warning(f"Could not save config: {e}")

# Load configuration
CONFIG = load_config()
logger.debug_mode = CONFIG.get("debug", False)

# ============================================================================
# STATE MANAGEMENT (Thread-Safe)
# ============================================================================

class StateManager:
    """Thread-safe state management"""
    
    def __init__(self):
        self.lock = threading.RLock()
        self.sessions: Dict[str, Any] = {}
        self.processes: Dict[str, subprocess.Popen] = {}
        self.ready_events: Dict[str, threading.Event] = {}
        self.allocated_ports: set = set()
        self.load_state()
    
    def load_state(self):
        """Load state from file"""
        try:
            if STATE_FILE.exists():
                with open(STATE_FILE, 'r') as f:
                    data = json.load(f)
                    self.sessions = data.get("sessions", {})
                    allocated = data.get("allocated_ports", [])
                    self.allocated_ports = set(allocated) if allocated else set()
                logger.info(f"State loaded: {len(self.sessions)} sessions")
        except Exception as e:
            logger.warning(f"State load error: {e}")
    
    def save_state(self):
        """Save state to file atomically"""
        try:
            tmp_file = STATE_FILE.with_suffix('.tmp')
            data = {
                "sessions": self.sessions,
                "allocated_ports": list(self.allocated_ports),
                "saved_at": datetime.now().isoformat(),
            }
            with open(tmp_file, 'w') as f:
                json.dump(data, f, indent=2)
            os.replace(tmp_file, STATE_FILE)
        except Exception as e:
            logger.debug(f"State save error: {e}")
    
    def get_session(self, session_id: str) -> Optional[Dict]:
        with self.lock:
            return self.sessions.get(session_id)
    
    def get_all_sessions(self) -> list:
        with self.lock:
            return list(self.sessions.values())
    
    def add_session(self, session_id: str, data: Dict):
        with self.lock:
            self.sessions[session_id] = data
            self.ready_events[session_id] = threading.Event()
            self.save_state()
    
    def update_session(self, session_id: str, updates: Dict):
        with self.lock:
            if session_id in self.sessions:
                self.sessions[session_id].update(updates)
                self.save_state()
    
    def remove_session(self, session_id: str) -> bool:
        with self.lock:
            if session_id in self.sessions:
                # Release ports
                ports = self.sessions[session_id].get("ports", [])
                if ports:
                    self.allocated_ports -= set(ports)
                
                del self.sessions[session_id]
                self.ready_events.pop(session_id, None)
                self.save_state()
                return True
            return False
    
    def allocate_ports(self, count: int) -> list:
        with self.lock:
            base = CONFIG.get("base_port", 10000)
            for attempt in range(1000):
                start = base + (attempt * (count + 1))
                port_range = set(range(start, start + count))
                if not self.allocated_ports & port_range:
                    self.allocated_ports.update(port_range)
                    return list(port_range)
            
            # Fallback
            fallback = list(range(base, base + count))
            self.allocated_ports.update(fallback)
            return fallback
    
    def release_ports(self, ports: list):
        with self.lock:
            self.allocated_ports -= set(ports)
    
    def get_active_count(self) -> int:
        with self.lock:
            return sum(
                1 for s in self.sessions.values()
                if s.get("status") in ("queued", "starting", "running")
            )

# Global state manager
STATE = StateManager()

# ============================================================================
# PORT ALLOCATION
# ============================================================================

def allocate_session_ports(session_id: str) -> list:
    """Allocate isolated ports for a session"""
    count = CONFIG.get("ports_per_session", 10)
    ports = STATE.allocate_ports(count)
    logger.debug(f"Allocated ports {ports[:3]}... for {session_id}")
    return ports

def release_session_ports(ports: list):
    """Release session ports"""
    if ports:
        STATE.release_ports(ports)
        logger.debug(f"Released ports: {ports}")

# ============================================================================
# SESSION BUILDER (Crash-Proof)
# ============================================================================

class SessionBuilder:
    """Build SSHX sessions with full crash protection"""
    
    def __init__(self):
        self.executor = ThreadPoolExecutor(max_workers=10, thread_name_prefix="session-builder")
    
    def create_session(self, name: str = "") -> Dict[str, Any]:
        """Create a new session - NEVER crashes"""
        try:
            # Check max sessions
            active_count = STATE.get_active_count()
            max_sessions = CONFIG.get("max_sessions", 25)
            
            if active_count >= max_sessions:
                return {
                    "ok": False,
                    "error": f"Maximum sessions reached ({max_sessions})",
                    "error_code": "MAX_SESSIONS",
                    "active_sessions": active_count,
                }
            
            # Generate session ID
            session_id = secrets.token_hex(8)
            
            # Allocate ports
            ports = allocate_session_ports(session_id)
            
            # Create session record
            session_data = {
                "id": session_id,
                "name": name or f"workspace-{session_id[:6]}",
                "status": "queued",
                "progress": 5,
                "stage": "initializing",
                "message": "Session queued for creation",
                "sshx_url": None,
                "created_at": time.time(),
                "last_activity": time.time(),
                "ended_at": None,
                "error": None,
                "ports": ports,
                "network_enabled": CONFIG.get("enable_outbound", True),
            }
            
            STATE.add_session(session_id, session_data)
            
            # Submit async creation
            future = self.executor.submit(self._build_session_async, session_id)
            
            return {
                "ok": True,
                "ready": False,
                "session_id": session_id,
                "session": self._public_session(session_data),
                "message": "Session creation started",
            }
            
        except Exception as e:
            logger.error(f"Session creation failed: {e}")
            return {
                "ok": False,
                "error": str(e),
                "error_code": "CREATION_FAILED",
            }
    
    def _build_session_async(self, session_id: str):
        """Build session asynchronously - all exceptions caught"""
        try:
            self._do_build_session(session_id)
        except Exception as e:
            logger.error(f"Session {session_id} build FAILED: {e}")
            logger.debug(traceback.format_exc())
            
            # Update session with error
            session = STATE.get_session(session_id)
            if session:
                ports = session.get("ports", [])
                release_session_ports(ports)
                
                STATE.update_session(session_id, {
                    "status": "error",
                    "progress": 100,
                    "stage": "error",
                    "message": "Creation failed",
                    "error": str(e),
                    "ended_at": time.time(),
                })
            
            # Signal ready (with error)
            event = STATE.ready_events.get(session_id)
            if event:
                event.set()
    
    def _do_build_session(self, session_id: str):
        """Actually build the session"""
        session = STATE.get_session(session_id)
        if not session:
            return
        
        ports = session.get("ports", [])
        
        try:
            # Update status
            STATE.update_session(session_id, {
                "status": "starting",
                "progress": 10,
                "stage": "preparing",
                "message": "Preparing workspace environment",
                "last_activity": time.time(),
            })
            
            # Create workspace directory
            workspace_dir = SESSIONS_DIR / session_id / "workspace"
            workspace_dir.mkdir(parents=True, exist_ok=True)
            
            # Setup workspace
            STATE.update_session(session_id, {
                "progress": 25,
                "stage": "setup",
                "message": "Setting up workspace files",
            })
            
            self._setup_workspace(workspace_dir, session_id, ports)
            
            # Install and launch SSHX
            STATE.update_session(session_id, {
                "progress": 50,
                "stage": "installing_sshx",
                "message": "Installing SSHX",
            })
            
            sshx_path = self._ensure_sshx()
            
            # Launch SSHX
            STATE.update_session(session_id, {
                "progress": 65,
                "stage": "launching",
                "message": "Launching SSHX process",
            })
            
            process = self._launch_sshx(workspace_dir, sshx_path, session_id, ports)
            
            if process:
                STATE.processes[session_id] = process
                
                # Watch for URL
                STATE.update_session(session_id, {
                    "progress": 75,
                    "stage": "waiting_url",
                    "message": "Waiting for SSHX access URL",
                })
                
                # Start watcher thread
                watcher = threading.Thread(
                    target=self._watch_process,
                    args=(session_id, process),
                    daemon=True
                )
                watcher.start()
                
            else:
                raise RuntimeError("Failed to launch SSHX process")
                
        except Exception as e:
            raise
    
    def _setup_workspace(self, workspace_dir: Path, session_id: str, ports: list):
        """Setup workspace directory"""
        # Create profile
        profile_content = f"""#!/bin/sh
# DARKSSH v5.0 Workspace Profile
export HOME=/root
export USER=root
export TERM=dumb
export PS1="\\u@darkssh-{session_id}:\\w$ "
export DARKSSH_SESSION="{session_id}"
export DARKSSH_PORTS="{','.join(map(str, ports[:3]))}"
export NETWORK_ENABLED=1

# Safe stubs
tput() {{ :; }}
resize() {{ :; }}
stty() {{ :; }} 2>/dev/null || true
alias clear=':'
alias reset=':'
"""
        
        (workspace_dir / ".profile").write_text(profile_content)
        
        # Create MOTD
        motd = f"""=============================================
   DARKSSH v5.0 - Secure Workspace
=============================================
 Session: {session_id}
 Ports: {', '.join(map(str, ports[:3]))}
 Network: OUTBOUND ENABLED
 Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
=============================================
"""
        
        (workspace_dir / "motd.txt").write_text(motd)
    
    def _ensure_sshx(self) -> Optional[str]:
        """Ensure SSHX is available - multiple methods"""
        # Check PATH
        sshx_in_path = shutil.which("sshx")
        if sshx_in_path:
            return sshx_in_path
        
        # Check common locations
        for check_path in ["/usr/local/bin/sshx", "/usr/bin/sshx", "/bin/sshx"]:
            if os.path.exists(check_path):
                return check_path
        
        # Try to install via curl
        if shutil.which("curl"):
            try:
                result = subprocess.run(
                    ["bash", "-c", "curl -sSfL https://sshx.io/get | sh"],
                    capture_output=True,
                    text=True,
                    timeout=60,
                    env={**os.environ, "TERM": "dumb"}
                )
                
                # Check again
                sshx_in_path = shutil.which("sshx")
                if sshx_in_path:
                    return sshx_in_path
                    
            except Exception as e:
                logger.debug(f"SSHX curl install failed: {e}")
        
        # Download binary directly
        try:
            download_dir = DATA_DIR / "bin"
            download_dir.mkdir(exist_ok=True)
            
            sshx_binary = download_dir / "sshx"
            
            # Detect architecture
            machine = os.uname().machine
            if machine in ["x86_64", "amd64"]:
                url = "https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz"
            elif machine in ["aarch64", "arm64"]:
                url = "https://s3.amazonaws.com/sshx/sshx-aarch64-unknown-linux-musl.tar.gz"
            else:
                url = "https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz"
            
            logger.info(f"Downloading SSHX from {url}")
            
            tar_file = download_dir / "sshx.tar.gz"
            urllib.request.urlretrieve(url, tar_file)
            
            # Extract
            import tarfile
            with tarfile.open(tar_file, 'r:gz') as tar:
                tar.extractall(download_dir)
            
            tar_file.unlink(missing_ok=True)
            
            if sshx_binary.exists():
                sshx_binary.chmod(0o755)
                return str(sshx_binary)
                
        except Exception as e:
            logger.warning(f"SSHX direct download failed: {e}")
        
        return None
    
    def _launch_sshx(self, workspace_dir: Path, sshx_path: str, 
                      session_id: str, ports: list) -> Optional[subprocess.Popen]:
        """Launch SSHX process"""
        if not sshx_path or not os.path.exists(sshx_path):
            logger.error(f"SSHX binary not found: {sshx_path}")
            return None
        
        # Build command
        cmd = f"""set -e
export HOME=/root
export USER=root
export TERM=dumb
export DARKSSH_SESSION="{session_id}"
export NETWORK_ENABLED=1

if [ -f /workspace/motd.txt ]; then
    cat /workspace/motd.txt
fi

echo ""
echo "Network: OUTBOUND INTERNET ENABLED"
echo ""

if [ -x /tmp/sshx ]; then
    exec /tmp/sshx --quiet
elif command -v sshx >/dev/null 2>&1; then
    exec sshx --quiet
elif [ -x "{sshx_path}" ]; then
    exec "{sshx_path}" --quiet
else
    echo "ERROR: SSHX not found"
    exit 1
fi
"""
        
        env = os.environ.copy()
        env["TERM"] = "dumb"
        env["HOME"] = "/root"
        env["SSHX_QUIET"] = "1"
        
        try:
            process = subprocess.Popen(
                ["/bin/sh", "-c", cmd],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                env=env,
                cwd=str(workspace_dir),
                start_new_session=True
            )
            
            logger.info(f"SSHX launched for {session_id} (PID: {process.pid})")
            return process
            
        except Exception as e:
            logger.error(f"Failed to launch SSHX: {e}")
            return None
    
    def _watch_process(self, session_id: str, process: subprocess.Popen):
        """Watch SSHX process for URL"""
        url_pattern = re.compile(r'https://sshx\.io/s/[^\s\r\n\)\]}]+')
        
        try:
            for line in process.stdout:
                if line is None:
                    break
                    
                line = line.strip()
                if not line:
                    continue
                
                # Log output (filter noise)
                if "proot warning" in line.lower() or "ptrace" in line.lower():
                    logger.debug(f"[PROOT] {line}")
                elif "tput" in line.lower() or "term" in line.lower():
                    logger.debug(f"[TERM] {line}")
                else:
                    logger.info(f"[{session_id}] {line}")
                
                # Look for URL
                match = url_pattern.search(line)
                if match:
                    sshx_url = match.group(0).rstrip(".,);]")
                    
                    STATE.update_session(session_id, {
                        "status": "running",
                        "progress": 100,
                        "stage": "ready",
                        "message": "SSHX session ready - Network enabled",
                        "sshx_url": sshx_url,
                        "last_activity": time.time(),
                    })
                    
                    logger.success(f"Session {session_id} READY: {sshx_url}")
                    
                    # Signal ready
                    event = STATE.ready_events.get(session_id)
                    if event:
                        event.set()
                    
                    break
            
            # Process ended
            rc = process.wait()
            
            session = STATE.get_session(session_id)
            if session and session.get("status") != "deleted":
                ports = session.get("ports", [])
                release_session_ports(ports)
                
                STATE.update_session(session_id, {
                    "status": "stopped" if rc == 0 else "error",
                    "ended_at": time.time(),
                    "error": f"SSHX exited with code {rc}" if rc else None,
                })
                
                event = STATE.ready_events.get(session_id)
                if event:
                    event.set()
                    
        except Exception as e:
            logger.error(f"Watch error for {session_id}: {e}")
            
            # Ensure event is set
            event = STATE.ready_events.get(session_id)
            if event:
                event.set()
        
        finally:
            STATE.processes.pop(session_id, None)
    
    def _public_session(self, session: Dict) -> Dict:
        """Return safe public session data"""
        return {
            "id": session.get("id"),
            "name": session.get("name"),
            "status": session.get("status"),
            "progress": session.get("progress", 0),
            "stage": session.get("stage"),
            "message": session.get("message"),
            "sshx_url": session.get("sshx_url"),
            "created_at": session.get("created_at"),
            "last_activity": session.get("last_activity"),
            "ended_at": session.get("ended_at"),
            "error": session.get("error"),
            "network_enabled": session.get("network_enabled"),
        }
    
    def wait_for_session(self, session_id: str, timeout: int = 90) -> Tuple[bool, Optional[Dict]]:
        """Wait for session to be ready"""
        event = STATE.ready_events.get(session_id)
        if not event:
            return False, {"error": "Session not found"}
        
        # Use shorter timeout for Cloudflare compatibility
        if event.wait(timeout=min(timeout, 90)):
            session = STATE.get_session(session_id)
            if session and session.get("sshx_url"):
                return True, session
            elif session and session.get("error"):
                return False, session
            return False, session
        
        return False, {"error": "Timeout waiting for session"}
    
    def delete_session(self, session_id: str) -> bool:
        """Delete a session"""
        session = STATE.get_session(session_id)
        if not session:
            return False
        
        # Kill process
        process = STATE.processes.get(session_id)
        if process and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(5)
            except Exception:
                try:
                    process.kill()
                except Exception:
                    pass
        
        # Remove workspace
        workspace = SESSIONS_DIR / session_id
        shutil.rmtree(workspace, ignore_errors=True)
        
        # Remove from state
        STATE.remove_session(session_id)
        
        logger.info(f"Session {session_id} deleted")
        return True

# Global session builder
BUILDER = SessionBuilder()

# ============================================================================
# HTTP API HANDLER (Cloudflare-Ready)
# ============================================================================

class RequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler that NEVER crashes"""
    
    # Suppress default logging
    def log_message(self, format, *args):
        pass
    
    def _send_json_response(self, code: int, data: Dict):
        """Send JSON response - ALWAYS succeeds"""
        try:
            response_body = json.dumps(data, ensure_ascii=False).encode('utf-8')
            
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, Accept")
            self.send_header("Content-Length", str(len(response_body)))
            self.end_headers()
            self.wfile.write(response_body)
            
        except Exception as e:
            logger.error(f"Response send error: {e}")
            # Try to send minimal response
            try:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(b'{"error":"Internal error"}')
            except Exception:
                pass
    
    def _read_body(self) -> Dict:
        """Read request body safely"""
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            if content_length > 1048576:  # 1MB limit
                return {}
            
            body = self.rfile.read(content_length)
            return json.loads(body) if body else {}
        except Exception:
            return {}
    
    def _check_auth(self) -> bool:
        """Check API authentication"""
        api_key = CONFIG.get("api_key", "")
        if not api_key:
            return True
        
        auth_header = self.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            return secrets.compare_digest(token, api_key)
        
        return False
    
    def do_OPTIONS(self):
        """Handle CORS preflight"""
        self._send_json_response(200, {"ok": True})
    
    def do_GET(self):
        """Handle GET requests - NEVER crashes"""
        try:
            path = self.path.split("?")[0]
            
            # Health endpoint (no auth required)
            if path in ("/", "/index.html"):
                self._serve_index()
                return
            
            if path == "/api/health":
                self._handle_health()
                return
            
            if path == "/api/version":
                self._send_json_response(200, {
                    "version": "5.0.0",
                    "name": "DARKSSH Universal Server",
                    "cloudflare_ready": True,
                })
                return
            
            # Auth required for other endpoints
            if not self._check_auth():
                self._send_json_response(401, {
                    "ok": False,
                    "error": "Unauthorized - API key required",
                    "error_code": "UNAUTHORIZED",
                })
                return
            
            # Sessions list
            if path == "/api/sessions":
                sessions = [BUILDER._public_session(s) for s in STATE.get_all_sessions()]
                self._send_json_response(200, {
                    "ok": True,
                    "sessions": sessions,
                    "total": len(sessions),
                    "active": STATE.get_active_count(),
                })
                return
            
            # Single session
            if path.startswith("/api/sessions/"):
                session_id = path.rsplit("/", 1)[-1]
                session = STATE.get_session(session_id)
                if session:
                    self._send_json_response(200, {
                        "ok": True,
                        "session": BUILDER._public_session(session),
                    })
                else:
                    self._send_json_response(404, {
                        "ok": False,
                        "error": "Session not found",
                        "error_code": "NOT_FOUND",
                    })
                return
            
            # 404
            self._send_json_response(404, {
                "ok": False,
                "error": "Not found",
                "error_code": "NOT_FOUND",
            })
            
        except Exception as e:
            logger.error(f"GET handler error: {e}")
            self._send_json_response(500, {
                "ok": False,
                "error": "Internal server error",
                "error_code": "INTERNAL_ERROR",
            })
    
    def do_POST(self):
        """Handle POST requests - NEVER crashes"""
        try:
            path = self.path.split("?")[0]
            
            # Auth check
            if not self._check_auth():
                self._send_json_response(401, {
                    "ok": False,
                    "error": "Unauthorized - API key required",
                    "error_code": "UNAUTHORIZED",
                })
                return
            
            # Create session
            if path == "/api/sessions":
                self._handle_create_session()
                return
            
            # Heartbeat
            if path.endswith("/heartbeat"):
                parts = path.split("/")
                session_id = parts[-2]
                session = STATE.get_session(session_id)
                if session:
                    STATE.update_session(session_id, {"last_activity": time.time()})
                    self._send_json_response(200, {"ok": True})
                else:
                    self._send_json_response(404, {
                        "ok": False,
                        "error": "Session not found",
                    })
                return
            
            self._send_json_response(404, {
                "ok": False,
                "error": "Not found",
            })
            
        except Exception as e:
            logger.error(f"POST handler error: {e}")
            self._send_json_response(500, {
                "ok": False,
                "error": "Internal server error",
                "error_code": "INTERNAL_ERROR",
            })
    
    def do_DELETE(self):
        """Handle DELETE requests - NEVER crashes"""
        try:
            path = self.path.split("?")[0]
            
            # Auth check
            if not self._check_auth():
                self._send_json_response(401, {
                    "ok": False,
                    "error": "Unauthorized",
                })
                return
            
            # Delete session
            if path.startswith("/api/sessions/"):
                session_id = path.rsplit("/", 1)[-1]
                ok = BUILDER.delete_session(session_id)
                self._send_json_response(200 if ok else 404, {
                    "ok": ok,
                    "error": None if ok else "Session not found",
                })
                return
            
            self._send_json_response(404, {"ok": False, "error": "Not found"})
            
        except Exception as e:
            logger.error(f"DELETE handler error: {e}")
            self._send_json_response(500, {
                "ok": False,
                "error": "Internal server error",
            })
    
    def _serve_index(self):
        """Serve index page"""
        try:
            html_path = SCRIPT_DIR / "static" / "index.html"
            if html_path.exists():
                html = html_path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(html)))
                self.end_headers()
                self.wfile.write(html)
            else:
                # Default HTML
                html = f"""<!DOCTYPE html>
<html><head><title>DARKSSH v5.0</title></head>
<body>
<h1>🚀 DARKSSH v5.0 Server</h1>
<p>Status: <b>Running</b></p>
<p>Version: 5.0.0</p>
<p>API: <a href="/api/health">/api/health</a></p>
</body></html>""".encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(html)))
                self.end_headers()
                self.wfile.write(html)
        except Exception as e:
            self._send_json_response(500, {"error": str(e)})
    
    def _handle_health(self):
        """Handle health check endpoint"""
        health_data = {
            "ok": True,
            "status": "healthy",
            "version": "5.0.0",
            "name": "DARKSSH Universal Server",
            "cloudflare_ready": True,
            "port": CONFIG.get("port", 4545),
            "uptime": time.time() - getattr(self.server, 'start_time', time.time()),
            "system": {
                "platform": os.uname().sysname,
                "architecture": os.uname().machine,
                "python": sys.version.split()[0],
            },
            "config": {
                "max_sessions": CONFIG.get("max_sessions", 25),
                "universal_mode": CONFIG.get("universal_mode", True),
                "outbound_enabled": CONFIG.get("enable_outbound", True),
            },
            "sessions": {
                "active": STATE.get_active_count(),
                "total": len(STATE.sessions),
            },
            "auth": "enabled" if CONFIG.get("api_key") else "disabled",
            "timestamp": datetime.now().isoformat(),
        }
        self._send_json_response(200, health_data)
    
    def _handle_create_session(self):
        """Handle session creation request"""
        try:
            body = self._read_body()
            name = body.get("name", "")
            
            # Check for async mode
            query = self.path.split("?")[-1] if "?" in self.path else ""
            is_async = query in ["wait=false", "async=1", "async=true"]
            
            # Create session
            result = BUILDER.create_session(name)
            
            if not result.get("ok"):
                self._send_json_response(400, result)
                return
            
            session_id = result.get("session_id")
            
            if is_async:
                # Return immediately
                self._send_json_response(202, {
                    "ok": True,
                    "ready": False,
                    "session_id": session_id,
                    "session": result.get("session"),
                    "message": "Session creation in progress",
                })
                return
            
            # Wait for session (with timeout for Cloudflare)
            timeout = CONFIG.get("session_timeout", 90)
            ready, session = BUILDER.wait_for_session(session_id, timeout)
            
            if ready and session:
                self._send_json_response(200, {
                    "ok": True,
                    "ready": True,
                    "session_id": session_id,
                    "session": BUILDER._public_session(session),
                    "message": "Session ready!",
                })
            elif session:
                error = session.get("error", "Unknown error")
                self._send_json_response(502 if "timeout" in error.lower() else 500, {
                    "ok": False,
                    "ready": False,
                    "error": error,
                    "session_id": session_id,
                    "session": BUILDER._public_session(session) if session else None,
                })
            else:
                self._send_json_response(404, {
                    "ok": False,
                    "ready": False,
                    "error": "Session disappeared",
                })
                
        except Exception as e:
            logger.error(f"Create session error: {e}")
            self._send_json_response(500, {
                "ok": False,
                "error": str(e),
                "error_code": "CREATION_ERROR",
            })

# ============================================================================
# THREADED HTTP SERVER
# ============================================================================

class ThreadedHTTPServer(ThreadingHTTPServer):
    """Threaded HTTP server that handles multiple connections"""
    daemon_threads = True
    allow_reuse_address = True
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_time = time.time()

# ============================================================================
# JANITOR (Cleanup Thread)
# ============================================================================

def run_janitor():
    """Background cleanup thread"""
    while True:
        try:
            time.sleep(30)  # Check every 30 seconds
            
            idle_timeout = CONFIG.get("idle_minutes", 30) * 60
            now = time.time()
            
            # Find stale sessions
            to_delete = []
            for session_id, session in STATE.sessions.items():
                if session.get("status") in ("queued", "starting", "running"):
                    last_activity = session.get("last_activity", now)
                    if now - last_activity > idle_timeout:
                        to_delete.append(session_id)
            
            # Delete stale sessions
            for session_id in to_delete:
                logger.info(f"Idle timeout: deleting {session_id}")
                BUILDER.delete_session(session_id)
                
        except Exception as e:
            logger.debug(f"Janitor error: {e}")

# Start janitor
threading.Thread(target=run_janitor, daemon=True).start()

# ============================================================================
# SIGNAL HANDLERS
# ============================================================================

def cleanup(signum=None, frame=None):
    """Clean shutdown"""
    logger.info("Shutting down...")
    
    # Stop all processes
    for session_id, process in list(STATE.processes.items()):
        try:
            if process.poll() is None:
                process.terminate()
                process.wait(3)
        except Exception:
            pass
    
    # Save state
    STATE.save_state()
    
    logger.close()
    sys.exit(0)

signal.signal(signal.SIGINT, cleanup)
signal.signal(signal.SIGTERM, cleanup)
if hasattr(signal, 'SIGCHLD'):
    signal.signal(signal.SIGCHLD, signal.SIG_IGN)

# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='DARKSSH v5.0 Universal Server')
    parser.add_argument('--port', type=int, help='Server port')
    parser.add_argument('--host', type=str, help='Server host')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    parser.add_argument('--api-key', type=str, help='API key for authentication')
    args = parser.parse_args()
    
    # Apply CLI overrides
    if args.port:
        CONFIG['port'] = args.port
    if args.host:
        CONFIG['host'] = args.host
    if args.debug:
        CONFIG['debug'] = True
        logger.debug_mode = True
    if args.api_key:
        CONFIG['api_key'] = args.api_key
    
    # Print banner
    banner = """
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║     ██████╗ ██╗   ██╗ █████╗ ███╗   ██╗ ██████╗ ███████╗        ║
║     ██╔══██╗██║   ██║██╔══██╗████╗  ██║██╔════╝ ██╔════╝        ║
║     ██████╔╝██║   ██║███████║██╔██╗ ██║██║  ███╗█████╗          ║
║     ██╔══██╗██║   ██║██╔══██║██║╚██╗██║██║   ██║██╔══╝          ║
║     ██████╔╝╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝███████╗        ║
║     ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝        ║
║                                                                   ║
║               ★ v5.0 - CLOUDFLARE-READY ★                         ║
║         Universal • Crash-Proof • 502-Free • Terminal Ready       ║
╚═══════════════════════════════════════════════════════════════════╝
"""
    print(banner)
    print(f"  Version: 5.0.0 (Cloudflare-Ready)")
    print(f"  Python: {sys.version.split()[0]}")
    print(f"  System: {os.uname().sysname} ({os.uname().machine})")
    print(f"  Port: {CONFIG['port']}")
    print(f"  API Key: {'Set' if CONFIG.get('api_key') else 'Not set'}")
    print(f"  Debug: {'On' if CONFIG.get('debug') else 'Off'}")
    print()
    
    # Start server
    host = CONFIG.get("host", "0.0.0.0")
    port = int(CONFIG.get("port", 4545))
    
    try:
        server = ThreadedHTTPServer((host, port), RequestHandler)
        logger.success(f"DARKSSH v5.0 server running on {host}:{port}")
        logger.info("Press Ctrl+C to stop")
        print()
        print("=" * 70)
        print(f"  ✅ SERVER READY - Listening on {host}:{port}")
        print(f"  ✅ Cloudflare Compatible: YES")
        print(f"  ✅ Health Check: http://{host}:{port}/api/health")
        print("=" * 70)
        print()
        
        server.serve_forever()
        
    except OSError as e:
        if "Address already in use" in str(e):
            logger.error(f"Port {port} is already in use!")
            logger.info(f"Try: python3 {sys.argv[0]} --port {port + 1}")
        else:
            logger.error(f"Server error: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        cleanup()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
