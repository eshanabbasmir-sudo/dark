#!/usr/bin/env bash
# ============================================================================
# DARKSSH v5.0 - Universal Server Launcher
# ============================================================================
# Usage: ./start_server.sh [options]
#
# Options:
#   --port PORT       Server port (default: 4545)
#   --host HOST      Server host (default: 0.0.0.0)
#   --debug          Enable debug mode
#   --api-key KEY    Set API key
#   --help           Show help
# ============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║                                                      ║"
echo "║   ${BOLD}DARKSSH v5.0 Server Launcher${NC}              ${CYAN}║"
echo "║                                                      ║"
echo "║   ${GREEN}Cloudflare-Ready • 502-Free • Universal${NC}     ${CYAN}║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check Python 3
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Error: Python 3 is required${NC}"
    exit 1
fi

# Create directories
mkdir -p data/sessions data/bin logs static

# Create default index.html if not exists
if [ ! -f "static/index.html" ]; then
    mkdir -p static
    cat > static/index.html << 'HTMLEOF'
<!DOCTYPE html>
<html>
<head>
    <title>DARKSSH v5.0 Server</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
               max-width: 800px; margin: 50px auto; padding: 20px; background: #1a1a2e; color: #eee; }
        h1 { color: #00d9ff; border-bottom: 2px solid #00d9ff; padding-bottom: 10px; }
        .status { background: #16213e; padding: 20px; border-radius: 10px; margin: 20px 0; }
        .ok { color: #00ff88; }
        .info { color: #ffd700; }
        code { background: #0f3460; padding: 2px 8px; border-radius: 4px; }
        pre { background: #0f3460; padding: 15px; border-radius: 8px; overflow-x: auto; }
        button { background: #00d9ff; color: #000; border: none; padding: 10px 20px; 
                 border-radius: 5px; cursor: pointer; font-weight: bold; }
        button:hover { background: #00ff88; }
    </style>
</head>
<body>
    <h1>🚀 DARKSSH v5.0 Server</h1>
    <div class="status">
        <p class="ok">✅ Server Status: <b>RUNNING</b></p>
        <p>Version: <b>5.0.0</b> (Cloudflare-Ready)</p>
        <p>API Endpoints:</p>
        <ul>
            <li><code>GET /api/health</code> - Health check</li>
            <li><code>POST /api/sessions</code> - Create session</li>
            <li><code>GET /api/sessions</code> - List sessions</li>
            <li><code>DELETE /api/sessions/:id</code> - Delete session</li>
        </ul>
    </div>
    <div class="info">
        <p>💡 <b>Curl Example:</b></p>
        <pre>curl -X POST http://localhost:4545/api/sessions \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"name":"test-workspace"}'</pre>
    </div>
</body>
</html>
HTMLEOF
    echo -e "${BLUE}Created default index.html${NC}"
fi

# Parse arguments
ARGS=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --port)
            ARGS="$ARGS --port $2"
            shift 2
            ;;
        --host)
            ARGS="$ARGS --host $2"
            shift 2
            ;;
        --debug)
            ARGS="$ARGS --debug"
            shift
            ;;
        --api-key)
            ARGS="$ARGS --api-key $2"
            shift 2
            ;;
        --help|-h)
            echo "DARKSSH v5.0 Server Launcher"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --port PORT       Server port (default: 4545)"
            echo "  --host HOST      Server host (default: 0.0.0.0)"
            echo "  --debug          Enable debug mode"
            echo "  --api-key KEY    Set API key for authentication"
            echo "  --help, -h       Show this help"
            echo ""
            exit 0
            ;;
        *)
            echo -e "${YELLOW}Unknown option: $1${NC}"
            shift
            ;;
    esac
done

echo -e "${YELLOW}Starting DARKSSH v5.0 Server...${NC}"
echo ""

# Run server
exec python3 "$SCRIPT_DIR/darkssh_v5_server.py" $ARGS
